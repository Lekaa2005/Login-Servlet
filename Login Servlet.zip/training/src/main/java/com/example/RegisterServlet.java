package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLIntegrityConstraintViolationException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
      protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
            String uname = request.getParameter("username");
            String pass = request.getParameter("password");

            response.setContentType("text/html");
            PrintWriter out = response.getWriter();

            try {
                Connection con =DBConnect.getConnection();
                if (con != null) {
                      PreparedStatement ps = con.prepareStatement(
                              "INSERT INTO users (username, password) VALUES (?, ?)");
                ps.setString(1, uname);
                ps.setString(2, pass);

                int i = ps.executeUpdate();

                if (i > 0) {
                      out.println("<h2>Registered successfully!</h2>");
                      out.println("<a href='login.html'>Login here</a>");
                } else {
                      out.println("<h2>Registration failed. Please try again.</h2>");
            } }else {
                out.println("<h2>Database connection failed!</h2>");
            }
            } catch (SQLIntegrityConstraintViolationException e) {
                                                          // Duplicate username error
                      out.println("<h2>User already exists!</h2>");
                      out.println("<a href='register.html'>Try again</a>");
            } catch (Exception e) {
                      e.printStackTrace();
                      out.println("<h2>Internal error occurred. Please try again later.</h2>");
            }
}}