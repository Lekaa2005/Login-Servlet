package com.example;

import java.sql.*;
public class DBConnect{
	public static Connection getConnection() {
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/userdb",
					"root",
					"1234"
					);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return con;
	}
}