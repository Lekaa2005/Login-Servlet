package com.example;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/hello")
public class WelcomeServlet extends HttpServlet{
	protected void doGet(HttpServletRequest request,HttpServletResponse response)
	throws ServletException, IOException{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<h1>Hello, Servlet Without web.xml!</h1>");
	}
}