package com.example;

import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
          String uname= request.getParameter("username");
          String pass =request.getParameter("password");

          try {
              Connection con =DBConnect.getConnection();
              PreparedStatement ps=con.prepareStatement("SELECT * FROM users WHERE username=? AND password=?");
              ps.setString(1, uname);
              ps.setString(2, pass);
              ResultSet rs =ps.executeQuery();

              if (rs.next()) {
                   response.sendRedirect("WelcomePage.jsp");
              } else {
                    PrintWriter out= response.getWriter();
                    out.println("<h2>Login Failed. Invalid credentials.</h2>");
                    out.println("<a href='login.html'>Try Again</a>");
              }
          } catch (Exception e) {
              e.printStackTrace();
}
}}